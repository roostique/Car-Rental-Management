/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import java.awt.HeadlessException;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author rustemsupayev
 */
public class RentHistory extends javax.swing.JInternalFrame {
     // Creates new form AddMember

       Connection conn=null;
       PreparedStatement pst=null;
       ResultSet rs=null;

    public RentHistory() {
        initComponents();
        conn=DBConnect.connect();
        tablelord();
        Fillcombo();  
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblRentHistory = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        fromdate = new com.toedter.calendar.JDateChooser();
        jLabel3 = new javax.swing.JLabel();
        todate = new com.toedter.calendar.JDateChooser();
        btnFilter = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        cmbRecord = new javax.swing.JComboBox();

        setClosable(true);
        setPreferredSize(new java.awt.Dimension(950, 540));

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));

        jLabel10.setFont(new java.awt.Font("Lucida Grande", 1, 24)); // NOI18N
        jLabel10.setText("Rent History");

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel1.setText("Member ID:");

        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(61, 61, 61)
                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtSearch, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)))
                .addContainerGap())
        );

        jButton2.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jButton2.setText("Clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        tblRentHistory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tblRentHistory);

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel2.setText("From:");

        fromdate.setDateFormatString("yyyy-MM-dd");

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel3.setText("To:");

        todate.setDateFormatString("yyyy-MM-dd");

        btnFilter.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        btnFilter.setText("Filter");
        btnFilter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFilterActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jButton1.setText("Delete record");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        cmbRecord.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(fromdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(44, 44, 44)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(todate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(137, 137, 137)
                                .addComponent(btnFilter)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 128, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                            .addComponent(cmbRecord, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(167, 167, 167)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(cmbRecord, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fromdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(todate, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(3, 3, 3)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addComponent(btnFilter))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // TODO add your handling code here:
        
        try {
                  String sql="SELECT `mid`, `name`, `nic`, `dob`, `sex`, `address`, `email`, `pnumber`, `occupation` "
                          + "FROM `addmembers` where name='%"+txtSearch.getText()+"%'";
                  pst=(PreparedStatement) conn.prepareStatement(sql);
                  rs=pst.executeQuery();
                  tblRentHistory.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
         
              } catch (Exception e) {
                  
                  JOptionPane.showConfirmDialog(rootPane, e);
                  
              }
        
    }//GEN-LAST:event_txtSearchActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        
       txtSearch.setText("");
      tablelord();
      ((JTextField)fromdate.getDateEditor().getUiComponent()).setText("");
      ((JTextField)todate.getDateEditor().getUiComponent()).setText("");
        
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased
        // TODO add your handling code here:
        
        
        try {
                  String sql="SELECT `record_no`, `mid`, `v_id`, `i_date`, `r_date` "
                          + "FROM `vehiclerelease` WHERE mid LIKE '%"+txtSearch.getText()+"%'";
                  pst=(PreparedStatement) conn.prepareStatement(sql);
                  rs=pst.executeQuery();
                  tblRentHistory.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
         
              } catch (Exception e) {
                  
                  JOptionPane.showConfirmDialog(rootPane, e);
                  
              }
        
    }//GEN-LAST:event_txtSearchKeyReleased

    private void btnFilterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFilterActionPerformed
        // TODO add your handling code here:
        
        RentFilter();
        
    }//GEN-LAST:event_btnFilterActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        int p=JOptionPane.showConfirmDialog(null, "Are you sure?","Внимание щщс", JOptionPane.YES_NO_OPTION);
        if (p==0){
        
        try {
            
            String sql= "DELETE FROM `vehiclereturn` WHERE record_no='"+cmbRecord.getSelectedItem()+"'";
            pst=(PreparedStatement) conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(rootPane, "Асет пидор");
            tablelord();
            
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(rootPane, e);
            
        }   
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void RentFilter()
    {
        String FDate=((JTextField)fromdate.getDateEditor().getUiComponent()).getText().toString();
        String TDate=((JTextField)todate.getDateEditor().getUiComponent()).getText().toString();
        if(FDate.length()>0 && TDate.isEmpty())
        {
         try {
         String reportSql="SELECT `record_no`, `mid`, `v_id`, `i_date`, `r_date` "
                 + "FROM `vehiclerelease` where i_date='"+FDate+"' and mid Like'%"+txtSearch.getText()+"%' ";
            pst=(PreparedStatement) conn.prepareStatement(reportSql);
            rs=pst.executeQuery();
            tblRentHistory.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
          
         } 
            catch (Exception e) {
                 JOptionPane.showMessageDialog(rootPane, "first date");
                                }
        }
     
        else if(FDate.length()>0 && TDate.length()>0)
        {
        try {
           String reportSql="SELECT `record_no`, `mid`, `v_id`, `i_date`, `r_date` "
                   + "FROM `vehiclerelease` where mid Like'%"+txtSearch.getText()+"%' and i_date between'"+FDate+"' and '"+TDate+"' ";
            pst=(PreparedStatement) conn.prepareStatement(reportSql);
            rs=pst.executeQuery();
            tblRentHistory.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
           
         } catch (Exception e) {
              JOptionPane.showMessageDialog(rootPane, e);
                                }
           }
        else
        {
          JOptionPane.showMessageDialog(rootPane, "Select date to filter data");  
        }    
    }
    
    
      private void Fillcombo()
    {
        
        try {
            
            String sql="SELECT * FROM `vehiclereturn`";
            pst=(PreparedStatement) conn.prepareStatement(sql);
                  rs=pst.executeQuery();  
                  
                  while (rs.next()){
                      
                      String record_no=rs.getString("record_no");
                      cmbRecord.addItem(record_no);
                      
                  }
            
        } catch (Exception e) {
            JOptionPane.showConfirmDialog(rootPane, e);
        }   
        
    }
    
     private void tablelord()
          {
              try {
                  String sql="SELECT `record_no`, `model`, `v_id`, `name`, `mid`, `i_date`, `r_date`, `late_days`, `fine` FROM `vehiclereturn`";
                  pst=(PreparedStatement) conn.prepareStatement(sql);
                  rs=pst.executeQuery();
                  tblRentHistory.setModel(net.proteanit.sql.DbUtils.resultSetToTableModel(rs));
         
              } catch (Exception e) { 
                  
                  JOptionPane.showConfirmDialog(rootPane, e);
                  
              }
 
          }
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFilter;
    private javax.swing.JComboBox cmbRecord;
    private com.toedter.calendar.JDateChooser fromdate;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblRentHistory;
    private com.toedter.calendar.JDateChooser todate;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
